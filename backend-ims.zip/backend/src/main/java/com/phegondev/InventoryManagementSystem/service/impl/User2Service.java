//package com.phegondev.InventoryManagementSystem.service.impl;
//
//import com.phegondev.InventoryManagementSystem.entity.User2;
//import com.phegondev.InventoryManagementSystem.repository.User2Repository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class User2Service {
//    @Autowired
//    User2Repository user2Repository;
//
//    public List<User2> getAllUsers(){
//        return user2Repository.findAll();
//    }
//    public User2 saveUser(User2 user) {
//        return user2Repository.save(user);
//    }
//}
