package com.phegondev.InventoryManagementSystem.enums;

public enum TransactionType {
    PURCHASE, SALE, RETURN_TO_SUPPLIER
}
