package com.phegondev.InventoryManagementSystem.enums;

public enum TransactionStatus {
    PENDING, PROCESSING, COMPLETED, CANCELED
}
