package com.phegondev.InventoryManagementSystem.enums;

public enum UserRoleEnum {
    ADMIN, MANAGER,USER
}
