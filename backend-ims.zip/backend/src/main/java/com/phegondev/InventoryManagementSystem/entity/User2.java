//package com.phegondev.InventoryManagementSystem.entity;
//
//        import lombok.Data;
//        import org.springframework.data.mongodb.core.mapping.Document;
//
//@Data
//@Document(collection = "users")
//public class User2 {
//    public String id;
//    public String username;
//    public String password;
//    public String role;
//}
