//package com.phegondev.InventoryManagementSystem.repository;
//
//import com.phegondev.InventoryManagementSystem.entity.User2;
//import org.springframework.data.mongodb.repository.MongoRepository;
//
//import java.util.Optional;
//
//public interface User2Repository extends MongoRepository<User2,String> {
//    Optional<User2> findByUsername(String s);
//}
